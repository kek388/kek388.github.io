@component('mail::message')
    # Introduction

    Thank you for registering

    @component('mail::button', ['url' => 'https://google.com'])
        Trying URL
    @endcomponent

    @component('mail::panel', ['url' => ''])
        Dunno what to type
    @endcomponent

    Thanks,<br>
    {{ config('app.name') }}
@endcomponent
