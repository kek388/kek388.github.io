<?php
    /**
     * Created by PhpStorm.
     * User: Kar Wai
     * Date: 3/13/2018
     * Time: 6:46 PM
     */

    namespace App;


    class Redis
    {

    }