<?php

    /**
     * Created by PhpStorm.
     * User: Kar Wai
     * Date: 3/13/2018
     * Time: 11:44 PM
     */

    namespace App\Billing;

    class stripe
    {
        protected $key;

        public function __construct($key)
        {
            $this->key = $key;
        }
    }