<?php
/**
 * Created by PhpStorm.
 * User: Kar Wai
 * Date: 2/6/2018
 * Time: 5:14 PM
 */

namespace App\Classes;


use FPDF;

class Pdf
{
    private $pdf;

    public function __construct()
    {
        header('Content-Type: application/pdf');
        $this->pdf = new FPDF('P', 'mm', 'A4');
    }

    public function initialize() {
        $this->basePage();
        $this->companyName();
        $this->companyAddress();
        $this->display();
    }

    private function basePage(){
        $this->pdf->AddPage();
        return $this->pdf;
    }

    private function companyName() {
        $this->pdf->SetFont('Arial', '', 10);
        $this->pdf->SetXY(10, 10);
        $this->pdf->Cell(50, 5, 'KEPM TECH SDN BHD', 1, 'J');
        return $this->pdf;
    }

    private function companyAddress() {
        $this->pdf->SetFont('Arial', '', 10);
        $this->pdf->SetXY(10, $this->pdf->GetY());
        $this->pdf->Cell(80, 5, '');
    }

    private function display(){
        $this->pdf->Output('test.pdf', 'I');
        exit;
    }
}