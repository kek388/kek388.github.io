<?php

namespace App\Classes;

use Goutte\Client;

/**
 * Created by PhpStorm.
 * User: Kar Wai
 * Date: 2/4/2018
 * Time: 6:22 PM
 */
class Coin
{
    const TRON_LINK = 'http://coinmarketcap.com/currencies/tron/';
    const OMISEGO_LINK = 'https://coinmarketcap.com/currencies/omisego/';
    const ETHEREUM_LINK = 'https://coinmarketcap.com/currencies/ethereum/';
    const STELLAR_LINK = 'https://coinmarketcap.com/currencies/stellar/';
    const BITCOIN_LINK = 'https://coinmarketcap.com/currencies/bitcoin/';


    private $client;
    private $coinArray;

    public function __construct()
    {
        $this->client = new Client();
        $this->coinArray = [
            'tron',
            'omisego',
            'ethereum',
            'stellar',
            'bitcoin'
        ];
    }

    public function initialize()
    {
        $guzzleClient = new \GuzzleHttp\Client([
            'timeout' => 5,
            'verify' => false,
        ]);

        $this->client->setClient($guzzleClient);
        foreach($this->coinArray as $coin) {

        }
    }
}