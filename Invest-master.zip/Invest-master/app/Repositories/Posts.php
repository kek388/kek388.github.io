<?php

    /**
     * Created by PhpStorm.
     * User: Kar Wai
     * Date: 3/13/2018
     * Time: 6:37 PM
     */

    namespace App\Repositories;

    use App\Post;
    use App\Redis;

    class Posts
    {
        protected $redis;

        public function __construct(Redis $redis)
        {
            $this->redis = $redis;
        }

        public function all()
        {
            return Post::all();
        }
    }